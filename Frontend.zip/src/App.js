import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./Home";
import Hotels from "./Hotels";
import Food from "./Food";
import Shopping from "./Shopping";
import Temples from "./Temples";

function App() {
  return (
    <Router>

      {/* MAIN NAVBAR (ONLY ONE) */}
      <div style={{
        display: "flex",
        justifyContent: "space-between",
        padding: "20px 40px",
        background: "#2c3e50",
        color: "white",
        alignItems: "center"
      }}>
        <h2>🌍 YatraMate</h2>

        <div style={{ display: "flex", gap: "25px" }}>
          <Link to="/" style={linkStyle}>Home</Link>
          <Link to="/hotels" style={linkStyle}>Hotels</Link>
          <Link to="/food" style={linkStyle}>Food</Link>
          <Link to="/shopping" style={linkStyle}>Shopping</Link>
          <Link to="/temples" style={linkStyle}>Temples</Link>
        </div>
      </div>

      {/* ROUTES */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/hotels" element={<Hotels />} />
        <Route path="/food" element={<Food />} />
        <Route path="/shopping" element={<Shopping />} />
        <Route path="/temples" element={<Temples />} />
      </Routes>

    </Router>
  );
}

const linkStyle = {
  color: "white",
  textDecoration: "none",
  fontWeight: "bold"
};

export default App;