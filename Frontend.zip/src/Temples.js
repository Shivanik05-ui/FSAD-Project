import React from "react";
import "./Page.css";

const places = [
  {
    name: "Tirupati Temple",
    img: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220"
  },
  {
    name: "Golden Temple",
    img: "https://images.unsplash.com/photo-1609947017136-9daf32a5eb16"
  },
  {
    name: "Meenakshi Temple",
    img: "https://images.unsplash.com/photo-1622308644420-b20142dc993c"
  }
];

function Temples() {
  return (
    <div className="container">
      <h2 className="title">Spiritual Destinations 🛕</h2>

      <div className="grid">
        {places.map((p, i) => (
          <div className="card" key={i}>
            <img src={p.img} className="img" />
            <div className="overlay">
              <h3>{p.name}</h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Temples;