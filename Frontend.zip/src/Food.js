function Food() {
  const places = [
    {
      name: "Fine Dining",
      image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0"
    },
    {
      name: "Street Food",
      image: "https://images.unsplash.com/photo-1600891964599-f61ba0e24092"
    },
    {
      name: "Cafes",
      image: "https://images.unsplash.com/photo-1509042239860-f550ce710b93"
    },
    {
      name: "Luxury Restaurants",
      image: "https://images.unsplash.com/photo-1552566626-52f8b828add9"
    }
  ];

  return (
    <div style={container}>
      <h1 style={title}>🍽️ Explore Food</h1>

      <div style={grid}>
        {places.map((item, index) => (
          <div key={index} style={card}>
            <img src={item.image} alt="" style={img} />
            <div style={overlay}>
              <h2>{item.name}</h2>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const container = {
  minHeight: "100vh",
  background: "linear-gradient(to right, #1e3c72, #2a5298)",
  padding: "40px",
  color: "white",
  textAlign: "center"
};

const title = {
  fontSize: "2.5rem",
  marginBottom: "30px"
};

const grid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
  gap: "20px"
};

const card = {
  position: "relative",
  borderRadius: "20px",
  overflow: "hidden",
  cursor: "pointer",
  transition: "transform 0.3s"
};

const img = {
  width: "100%",
  height: "250px",
  objectFit: "cover"
};

const overlay = {
  position: "absolute",
  bottom: "0",
  width: "100%",
  padding: "20px",
  background: "rgba(0,0,0,0.6)"
};

export default Food;