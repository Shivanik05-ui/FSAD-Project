import React from "react";
import "./Page.css";

const places = [
  {
    name: "Dubai Mall",
    img: "https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a"
  },
  {
    name: "Champs Elysees",
    img: "https://images.unsplash.com/photo-1543353071-873f17a7a088"
  },
  {
    name: "Orion Mall",
    img: "https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a"
  }
];

function Shopping() {
  return (
    <div className="container">
      <h2 className="title">Luxury Shopping Destinations 🛍️</h2>

      <div className="grid">
        {places.map((p, i) => (
          <div className="card" key={i}>
            <img src={p.img} className="img" />
            <div className="overlay">
              <h3>{p.name}</h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Shopping;