import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Page.css";

function Hotels() {
  const [hotels, setHotels] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8080/places/Hyderabad/hotel")
      .then((res) => {
        setHotels(res.data);
      })
      .catch((err) => {
        console.error(err);
      });
  }, []);

  return (
    <div className="container">
      <h2 className="title">Luxury Hotels & Stays 🏨</h2>

      <div className="grid">
        {hotels.map((hotel) => (
          <div className="card" key={hotel.id}>
            <img src={hotel.image_url} className="img" />

            <div className="overlay">
              <h3>{hotel.name}</h3>
              <p>{hotel.city}</p>
              <span>₹{hotel.price}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Hotels;