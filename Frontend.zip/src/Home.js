import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Home.css";

function Home() {
  const [city, setCity] = useState("");
  const [budget, setBudget] = useState("");
  const navigate = useNavigate();

  const handleSearch = () => {
    if (!city) return alert("Enter a city");
    navigate(`/hotels?city=${city}&budget=${budget}`);
  };

  return (
    <div className="home">

      {/* NAVBAR */}
      <div className="navbar">
        <h2 className="logo">🌍 YatraMate Premium</h2>

        <div className="nav-links">
          <span onClick={() => navigate("/")}>Home</span>
          <span onClick={() => navigate("/hotels")}>Hotels</span>
          <span onClick={() => navigate("/food")}>Food</span>
          <span onClick={() => navigate("/shopping")}>Shopping</span>
          <span onClick={() => navigate("/temples")}>Temples</span>
        </div>
      </div>

      {/* HERO */}
      <div className="hero">
        <h1 className="title">
          Luxury Travel Planner ✨
        </h1>

        <div className="search-box">
          <input
            placeholder="Enter City"
            value={city}
            onChange={(e) => setCity(e.target.value)}
          />
          <input
            placeholder="Budget ₹"
            value={budget}
            onChange={(e) => setBudget(e.target.value)}
          />
          <button onClick={handleSearch}>Search</button>
        </div>
      </div>

      {/* DESTINATIONS */}
      <div className="section">
        <h2>Popular Destinations</h2>

        <div className="cards">
          <div className="card" onClick={() => navigate("/hotels")}>
            <img src="https://images.unsplash.com/photo-1516483638261-f4dbaf036963" alt="Goa" />
            <p>Goa</p>
          </div>

          <div className="card">
            <img src="https://images.unsplash.com/photo-1502602898657-3e91760cbb34" alt="Paris" />
            <p>Paris</p>
          </div>

          <div className="card">
            <img src="https://images.unsplash.com/photo-1573843981267-be1999ff37cd" alt="Maldives" />
            <p>Maldives</p>
          </div>

          <div className="card">
            <img src="https://images.unsplash.com/photo-1518684079-3c830dcef090" alt="Dubai" />
            <p>Dubai</p>
          </div>
        </div>
      </div>

    </div>
  );
}

export default Home;