package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
public class PlaceController {

    @Autowired
    private PlaceRepository placeRepository;

    // Get all places
    @GetMapping("/places")
    public List<Place> getAllPlaces() {
        return placeRepository.findAll();
    }

    // Filter by city
    @GetMapping("/places/{city}")
    public List<Place> getByCity(@PathVariable String city) {
        return placeRepository.findByCity(city);
    }

    // Filter by city + type
    @GetMapping("/places/{city}/{type}")
    public List<Place> getByCityAndType(@PathVariable String city,
                                        @PathVariable String type) {
        return placeRepository.findByCityAndType(city, type);
    }
}